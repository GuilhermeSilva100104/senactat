# Aulas de GNU/Linux (Linux Mint)
