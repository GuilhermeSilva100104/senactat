# Diretório das aulas da UC (Unidade Curricular) 2 (Sistemas Operacionais Microsoft e GNU/Linux)
