# Técnico em Informática SENAC Tatuapé Turma: TEI-03-2021
Repositório das Aulas do Técnico em Informática do SENAC Tatuapé (Módulos de Harwdare e Redes)
